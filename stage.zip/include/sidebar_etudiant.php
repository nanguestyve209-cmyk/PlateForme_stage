<div class="offcanvas offcanvas-start  sidebar " tabindex="-1" id="sidebarMobile">
    <div class="offcanvas-header">
        <h3 class="text-white">Stage<span class="text-primary">Link</span></h3>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body">
        <ul class="list-unstyled mx-2 py-5">
            <li class="list-unstyled my-4"><i class="fa-solid fa-table-columns mx-2"></i><a href="" class="text-white text-decoration-none">Tableau de bord</a></li>
            <li class="list-unstyled my-4"><i class="fa-solid fa-user-graduate mx-2"></i><a href="profil_etudiant.php" class="text-white text-decoration-none">Mon profil</a></li>
            <li class="list-unstyled my-4"><i class="fa-solid fa-building mx-2"></i><a href="modification_cv.php" class="text-white text-decoration-none">Cv</a></li>
            <li class="list-unstyled my-4"><i class="fa-solid fa-clipboard mx-2"></i><a href="" class="text-white text-decoration-none">Offres de stage</a></li>
            <li class="list-unstyled my-4"><i class="fa-solid fa-briefcase mx-2"></i><a href="" class="text-white text-decoration-none">Mes candidatures</a></li>
            <li class="list-unstyled my-4"><i class="fa-solid fa-bell mx-2"></i><a href="" class="text-white text-decoration-none">Notifications</a></li>
            <li class="list-unstyled my-4"><i class="fa-solid fa-gear mx-2"></i><a href="" class="text-white text-decoration-none">Parametres</a></li>
            <li class="list-unstyled my-4"><i class="fa-solid fa-user-gear mx-2"></i><a href="" class="text-white text-decoration-none">Deconnexion</a></li>
        </ul>
    </div>
</div>