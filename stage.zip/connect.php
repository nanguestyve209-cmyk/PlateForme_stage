<?php
$con = new mysqli('localhost', 'root', '', 'stage_link');
if (!$con) {
    echo "connection successfull";
}
